"use server";

export async function myServerFunction(data: any) {
  // Logic to run on the server
  console.log("This is a server action!", data);
}