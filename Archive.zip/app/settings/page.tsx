import { SettingsPage } from "@/components/settings-page"

export default function Settings() {
  return <SettingsPage />
}
