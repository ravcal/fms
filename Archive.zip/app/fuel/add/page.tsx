import { AddFuelTransaction } from "@/components/add-fuel-transaction"

export default function AddFuelPage() {
  return <AddFuelTransaction />
}
